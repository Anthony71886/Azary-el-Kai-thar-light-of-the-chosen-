# Azary’el Flame: Light of the Chosen

This is the starter project for your app.  

## Run locally:
1. Install dependencies: `npm install`
2. Start metro: `npm start`
3. Run on Android: `npm run android`

## Build APK with GitHub:
1. Push this project to GitHub
2. Go to Actions tab
3. Wait for workflow to finish
4. Download APK from Releases
